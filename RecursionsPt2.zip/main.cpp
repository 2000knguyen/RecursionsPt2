/* 
 * Name: Kendrick Nguyen
 * Date: 25 February 2021
 * Recursion2.cpp
 * Three recursive problems.
 * Add your code to the four functions given below.
 * Do not change any part of the function headers (name, parameters, or return type).
 * Do not change any part of the main.
 * Do not create any global or static variables.
 */
#include <math.h> 
#include <iostream>
using namespace std;

/* Finds the maximum value in an array
 * @param array array of values (sorted or unsorted)
 * @param size length of the array
 * @param i iterator
 * @param max maximum value found so far
 * @return maximum value
 */
int maxArray( int array[], int size, int i, int max ) {
  if (i < size){
    if (max < array[i]){
      max = array[i];
    }
    return maxArray (array, size, i+1, max);
  }else if(size == 1){
    return array[0];
  }
  return max;
}

/* Finds the maximum value in an array
 * @param array array of values (sorted or unsorted)
 * @param size length of the array
 * @return maximum value
 */
int findMax( int array[], int size ){
  return maxArray(array, size, 0, 0);
}

/* Returns the number of times c appears in the string str
 * @param str string to test the frequency of the certain char, it passes to this function a  string
 * @param c character to find the amount of times a certain char was used
 * @return number of times the character appeared in the string
 */
int charFrequency( string str, char c ) {	
  if(str[0] == c){
    return 1 + charFrequency (str.substr(1), c);
  }else if (str.length() == 0){
    return 0;
  }
  return charFrequency(str.substr(1), c);
}

/**Converts a binary string to decimal
 * The pow function was made after being explained how to create it from multiple peers
 - takes the string and its length, subtracts a char value as well as an int value from the length, and then calls
 - the function again to create a recursion, but this time it takes in the bin sub string value. 
 - (It was very hard understanding how to do this part even after trying to search up ways to do it on google)
 **Notes**
 bin[0] - '0' ~ takes the string the first index of the string and takes out the 0 if there is one
 pow(2, bin.length() -1)) takes the current length, and uses that as the exponent for 2
  ex: 1101100, takes the length, 7, 2^7
 binToDec(bin.substr(1)) just takes the previous value calculated and adds it all together until the length is all gone
 * @param bin the binary string
 * @return the decimal value
 */
int binToDec( string bin ) {
	if (bin.length() != 0){
    return int(bin[0] - '0') * int(pow(2, bin.length() - 1)) + binToDec(bin.substr(1)); 
  }else{
    return 0;
  }
}

int main( ) {
	int array [] = { 46, 22, 7, 58, 91, 55, 31, 84, 12, 78 };
	if( findMax( array, 10 ) == 91 ) {
		cout<< "1. findMax is correct!" <<endl;
	}	
	if( charFrequency( "The quick brown fox jumps over the lazy dog.", 'o' ) == 4 ) {
		cout<< "2. charFrequency1 is correct!" <<endl;
	}
	if( charFrequency( "The quick brown fox jumps over the lazy dog.", 'e' ) == 3 ) {
		cout<< "3. charFrequency2 is correct!" <<endl;
	}
	if(binToDec("1101100") == 108) {
		cout << "4. binToDec1 is correct!" << endl;
	}
	if(binToDec("1011101") == 93) {
		cout << "5. binToDec2 is correct!" << endl;
	}
}